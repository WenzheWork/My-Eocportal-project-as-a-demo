Portal build

support screen resolution to 3840 * 1080

using bootstrap responsitive framework

leaflet plugin to support map rendering
